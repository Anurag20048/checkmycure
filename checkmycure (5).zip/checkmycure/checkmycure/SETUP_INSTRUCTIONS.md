# Check MyCure - Setup Instructions

## Changes Made

### 1. **Database Connection Fixed** ✅
- Added authentication API endpoints (`/api/auth/register/` and `/api/auth/login/`)
- User registration and login data now saves to the database
- Uses Django's built-in User model and Token authentication

### 2. **Logo Click Fixed** ✅
- Logo in login and signup pages now redirects to index.html when clicked
- Added cursor pointer for better UX

### 3. **Gender Input Updated** ✅
- Changed gender from textbox to radio buttons in signup.html
- Options: Male, Female, Others
- Gender data is now sent to backend during registration

### 4. **Emergency Profile Enhanced** ✅
- Added comprehensive fields:
  - Personal Information (name, age, gender, blood group, height, weight)
  - Emergency Contacts (primary & secondary with names/relations)
  - Medical Information (allergies, conditions, medications, surgeries, insurance, doctor)
  - Additional Information (special needs, DNR status)
- Modern, responsive design with gradient background
- Organized into clear sections with icons
- Improved form validation and user experience

## Running the Application

### Backend Setup

1. **Navigate to backend directory:**
   ```powershell
   cd "C:\Users\SUNNY KUMAR\OneDrive\Desktop\checkmycure\checkmycure\backend"
   ```

2. **Activate virtual environment (if you have one):**
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```

3. **Run migrations to update database:**
   ```powershell
   python manage.py makemigrations
   python manage.py migrate
   ```

4. **Start the Django server:**
   ```powershell
   python manage.py runserver 8001
   ```

   The backend API will be available at: `http://localhost:8001`

### Frontend Setup

1. **Open frontend directory:**
   ```powershell
   cd "C:\Users\SUNNY KUMAR\OneDrive\Desktop\checkmycure\checkmycure\frontend"
   ```

2. **Open index.html in browser:**
   - Simply double-click `index.html`, or
   - Use a local server (Live Server extension in VS Code)

## Testing the Fixes

### 1. Test User Registration
1. Go to signup page
2. Fill in all fields including the new gender radio buttons
3. Click "Sign Up"
4. Check that data is saved to database at `backend/db.sqlite3`

### 2. Test User Login
1. Go to login page
2. Enter registered email and password
3. Click "Login"
4. Should redirect to index.html with user logged in

### 3. Test Logo Click
1. While on login.html or signup.html
2. Click the logo at the top
3. Should navigate back to index.html

### 4. Test Emergency Profile
1. Navigate to `emergency-profile.html`
2. Fill in the comprehensive form with all new fields
3. Click "Save Emergency Profile"
4. Data should be saved to localStorage
5. Refresh page to verify fields are pre-filled

## API Endpoints

### Authentication
- **POST** `/api/auth/register/` - Register new user
  ```json
  {
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123",
    "gender": "male"
  }
  ```

- **POST** `/api/auth/login/` - Login user
  ```json
  {
    "email": "john@example.com",
    "password": "password123"
  }
  ```

Both endpoints return:
```json
{
  "token": "authentication_token_here",
  "user": {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

## Database Structure

User data is stored in Django's default User model:
- `username` - uses email
- `email` - user's email
- `password` - hashed password
- `first_name` - user's full name

Auth tokens are stored in the `authtoken_token` table.

## Troubleshooting

### Database Connection Issues
If you see database errors:
```powershell
python manage.py migrate --run-syncdb
```

### CORS Issues
If frontend can't connect to backend:
- Ensure backend is running on port 8001
- Check that CORS is enabled in `settings.py` (already configured)

### Auth Token Issues
If authentication fails:
```powershell
python manage.py shell
>>> from rest_framework.authtoken.models import Token
>>> Token.objects.all().delete()  # Clear all tokens
>>> exit()
```

## Next Steps

1. Test all functionality thoroughly
2. Consider adding email verification for registration
3. Add password reset functionality
4. Implement backend storage for emergency profiles (currently using localStorage)
5. Add profile picture upload functionality

## Notes

- Emergency profile data is currently stored in browser localStorage
- Consider moving to backend database for better security and accessibility
- All user passwords are properly hashed using Django's authentication system
- Token authentication is implemented for secure API access
