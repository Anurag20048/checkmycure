# Django Backend API

A complete Django REST API with database models for managing categories, products, customers, and orders.

## Features

- **Categories**: Manage product categories
- **Products**: CRUD operations for products with inventory tracking
- **Customers**: Customer management
- **Orders**: Order processing with items and status tracking
- **Admin Panel**: Full Django admin interface
- **REST API**: Complete RESTful API with Django REST Framework

## Database Models

1. **Category**: Product categories with descriptions
2. **Product**: Products with price, stock, and category relationships
3. **Customer**: Customer information with contact details
4. **Order**: Orders with status tracking (pending, processing, shipped, delivered, cancelled)
5. **OrderItem**: Individual items in orders

## Installation & Setup

### 1. Create Virtual Environment

```powershell
# Navigate to backend directory
cd D:\frontend\backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
.\venv\Scripts\activate
```

### 2. Install Dependencies

```powershell
pip install -r requirements.txt
```

### 3. Run Migrations

```powershell
python manage.py makemigrations
python manage.py migrate
```

### 4. Create Superuser (Admin)

```powershell
python manage.py createsuperuser
```

Follow the prompts to create an admin account.

### 5. Run Development Server

```powershell
python manage.py runserver 8001
```

The server will start at `http://127.0.0.1:8001/` (to match the frontend JS calls).

## API Endpoints

### Base URL: `http://127.0.0.1:8001/api/`

### Health endpoints (used by the provided frontend)
- `POST /api/predict/` - Symptom-based disease prediction
- `POST /api/chatbot/` - Simple health chatbot

### Optional auth (token)
- `POST /api/auth/register/` - Register (name, email, password) -> token
- `POST /api/auth/login/` - Login (email, password) -> token
- `GET /api/symptom-checks/` - List saved checks for the authenticated user (Token auth)

### Categories
- `GET /api/categories/` - List all categories
- `POST /api/categories/` - Create new category
- `GET /api/categories/{id}/` - Get category details
- `PUT /api/categories/{id}/` - Update category
- `DELETE /api/categories/{id}/` - Delete category
- `GET /api/categories/{id}/products/` - Get all products in category

### Products
- `GET /api/products/` - List all products
- `POST /api/products/` - Create new product
- `GET /api/products/{id}/` - Get product details
- `PUT /api/products/{id}/` - Update product
- `DELETE /api/products/{id}/` - Delete product
- `POST /api/products/{id}/update_stock/` - Update product stock

**Query Parameters:**
- `?category={id}` - Filter by category
- `?is_active=true` - Filter active products

### Customers
- `GET /api/customers/` - List all customers
- `POST /api/customers/` - Create new customer
- `GET /api/customers/{id}/` - Get customer details
- `PUT /api/customers/{id}/` - Update customer
- `DELETE /api/customers/{id}/` - Delete customer
- `GET /api/customers/{id}/orders/` - Get all customer orders

### Orders
- `GET /api/orders/` - List all orders
- `POST /api/orders/` - Create new order
- `GET /api/orders/{id}/` - Get order details
- `PUT /api/orders/{id}/` - Update order
- `DELETE /api/orders/{id}/` - Delete order
- `POST /api/orders/{id}/update_status/` - Update order status

**Query Parameters:**
- `?customer={id}` - Filter by customer
- `?status=pending` - Filter by status

## Admin Panel

Access the admin panel at: `http://127.0.0.1:8000/admin/`

Login with the superuser credentials you created.

## Example API Requests

### Create Category
```json
POST /api/categories/
{
    "name": "Electronics",
    "description": "Electronic devices and accessories"
}
```

### Create Product
```json
POST /api/products/
{
    "name": "Laptop",
    "description": "High performance laptop",
    "price": "999.99",
    "category": 1,
    "stock": 10,
    "is_active": true
}
```

### Create Customer
```json
POST /api/customers/
{
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1234567890",
    "address": "123 Main St"
}
```

### Create Order
```json
POST /api/orders/
{
    "customer": 1,
    "status": "pending",
    "notes": "Rush delivery",
    "items": [
        {
            "product": 1,
            "quantity": 2,
            "price": "999.99"
        }
    ]
}
```

## Testing the API

You can test the API using:
- **Browser**: Visit `http://127.0.0.1:8000/api/` for browsable API
- **Postman**: Import endpoints and test
- **cURL**: Command line testing
- **Python requests**: Programmatic access

## Project Structure

```
backend/
├── manage.py
├── requirements.txt
├── README.md
├── backend/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
└── api/
    ├── __init__.py
    ├── admin.py
    ├── apps.py
    ├── models.py
    ├── serializers.py
    ├── views.py
    └── urls.py
```

## Notes

- SQLite database is used by default (db.sqlite3)
- CORS is enabled for all origins (configure for production)
- Debug mode is ON (disable in production)
- Change SECRET_KEY in production
