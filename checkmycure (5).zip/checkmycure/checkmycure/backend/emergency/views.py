from rest_framework import status, viewsets
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import MedicalProfile, EmergencyContact, EmergencyLog
from .serializers import (
    MedicalProfileSerializer,
    EmergencyContactSerializer,
    EmergencyLogSerializer,
    SOSRequestSerializer,
)


class MedicalProfileView(APIView):
    """Get or update the authenticated user's medical profile."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        profile, _ = MedicalProfile.objects.get_or_create(user=request.user)
        serializer = MedicalProfileSerializer(profile)
        return Response(serializer.data)

    def put(self, request):
        profile, _ = MedicalProfile.objects.get_or_create(user=request.user)
        serializer = MedicalProfileSerializer(profile, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class EmergencyContactViewSet(viewsets.ModelViewSet):
    """CRUD for emergency contacts."""
    permission_classes = [IsAuthenticated]
    serializer_class = EmergencyContactSerializer

    def get_queryset(self):
        return EmergencyContact.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class EmergencyLogViewSet(viewsets.ReadOnlyModelViewSet):
    """Read-only access to emergency logs for authenticated users."""
    permission_classes = [IsAuthenticated]
    serializer_class = EmergencyLogSerializer

    def get_queryset(self):
        return EmergencyLog.objects.filter(user=self.request.user)


@api_view(['POST'])
@permission_classes([AllowAny])
def trigger_sos(request):
    """
    SOS endpoint - logs emergency and returns a pre-formatted message.
    Works for both authenticated and anonymous users.
    """
    serializer = SOSRequestSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    lat = serializer.validated_data['lat']
    lon = serializer.validated_data['lon']
    symptoms = serializer.validated_data.get('symptoms', [])

    user = request.user if request.user.is_authenticated else None

    # Build emergency message
    location_link = f"https://maps.google.com/?q={lat},{lon}"
    
    # Get additional data from request
    accuracy = request.data.get('accuracy')
    contacts_notified = request.data.get('contacts_notified', 0)
    hospitals_notified = request.data.get('hospitals_notified', 0)
    emergency_services_called = request.data.get('emergency_services_called', False)
    
    medical_snapshot = None

    if user:
        profile = MedicalProfile.objects.filter(user=user).first()
        contacts = EmergencyContact.objects.filter(user=user)
        if not contacts_notified:
            contacts_notified = contacts.count()

        message_parts = [
            "🚨 EMERGENCY ALERT 🚨",
            "",
            f"Name: {profile.name if profile and profile.name else user.username}",
            f"Location: {location_link}",
            "",
        ]

        if profile:
            # Create medical snapshot
            medical_snapshot = {
                'name': profile.name,
                'age': profile.age,
                'gender': profile.gender,
                'blood_group': profile.blood_group,
                'allergies': profile.allergies,
                'conditions': profile.conditions,
                'medications': profile.medications,
                'height': profile.height,
                'weight': profile.weight,
            }
            
            message_parts.extend([
                f"Blood Group: {profile.blood_group or 'N/A'}",
                f"Allergies: {profile.allergies or 'None'}",
                f"Conditions: {profile.conditions or 'None'}",
                f"Medications: {profile.medications or 'None'}",
                "",
            ])

        if symptoms:
            message_parts.append(f"Symptoms: {', '.join(symptoms)}")
            message_parts.append("")

        message_parts.append("Immediate medical assistance required.")
        message_parts.append("— Sent via Check MyCure")

        message = "\n".join(message_parts)
    else:
        contacts_notified = 0
        message = f"""🚨 EMERGENCY ALERT 🚨

Location: {location_link}

{"Symptoms: " + ", ".join(symptoms) if symptoms else "Critical Emergency"}

Immediate medical assistance required.
— Sent via Check MyCure"""

    # Log the emergency
    sos_log = EmergencyLog.objects.create(
        user=user,
        latitude=lat,
        longitude=lon,
        location_accuracy=accuracy,
        message=message,
        symptoms=symptoms,
        contacts_notified=contacts_notified,
        hospitals_notified=hospitals_notified,
        emergency_services_called=emergency_services_called,
        medical_snapshot=medical_snapshot,
        status='active'
    )

    return Response({
        "id": sos_log.id,
        "message": message,
        "location": location_link,
        "contacts_notified": contacts_notified,
        "status": "active"
    })
