from __future__ import annotations

from dataclasses import dataclass


SYMPTOM_KEYWORDS: list[str] = [
    "fever",
    "cough",
    "headache",
    "nausea",
    "fatigue",
    "pain",
    "tired",
    "vomit",
    "stomach",
]


@dataclass(frozen=True)
class DiseaseRule:
    name: str
    symptoms: set[str]
    base_confidence: float
    advice: str


DISEASE_RULES: list[DiseaseRule] = [
    DiseaseRule(
        name="Common Cold",
        symptoms={"cough", "headache", "fatigue", "fever"},
        base_confidence=0.75,
        advice=(
            "Rest, drink plenty of fluids, and consider over-the-counter cold medicines. "
            "If symptoms worsen or persist, consult a healthcare professional."
        ),
    ),
    DiseaseRule(
        name="Influenza (Flu)",
        symptoms={"fever", "cough", "fatigue", "headache", "pain"},
        base_confidence=0.80,
        advice=(
            "Get plenty of rest, stay hydrated, and consider medical advice if caught early. "
            "Seek urgent care for difficulty breathing, chest pain, or severe symptoms."
        ),
    ),
    DiseaseRule(
        name="Gastroenteritis (Stomach Flu)",
        symptoms={"nausea", "vomit", "stomach", "fatigue"},
        base_confidence=0.78,
        advice=(
            "Stay hydrated (oral rehydration solutions can help). Eat bland foods when you can. "
            "Seek medical care if you can't keep fluids down or symptoms are severe."
        ),
    ),
    DiseaseRule(
        name="Migraine",
        symptoms={"headache", "nausea", "fatigue"},
        base_confidence=0.72,
        advice=(
            "Rest in a dark, quiet room. Hydrate and consider over-the-counter pain relief. "
            "If headaches are frequent or severe, consult a clinician."
        ),
    ),
    DiseaseRule(
        name="Tension Headache",
        symptoms={"headache", "pain", "fatigue"},
        base_confidence=0.70,
        advice=(
            "Try stress reduction, hydration, gentle stretching, and OTC pain relief. "
            "Seek care if severe, sudden, or persistent."
        ),
    ),
    DiseaseRule(
        name="Upper Respiratory Infection",
        symptoms={"cough", "fever", "fatigue", "headache"},
        base_confidence=0.76,
        advice=(
            "Rest, hydrate, use a humidifier, and consider OTC symptom relief. "
            "See a doctor if symptoms worsen or do not improve."
        ),
    ),
    DiseaseRule(
        name="Food Poisoning",
        symptoms={"nausea", "vomit", "stomach", "fever"},
        base_confidence=0.74,
        advice=(
            "Hydrate, rest, and avoid heavy foods. Seek care if there is severe dehydration, "
            "blood in stool, or high fever."
        ),
    ),
    DiseaseRule(
        name="Viral Infection",
        symptoms={"fever", "fatigue", "headache", "pain"},
        base_confidence=0.68,
        advice=(
            "Rest and hydrate. Use OTC medications for symptom relief as directed. "
            "Consult a healthcare professional if symptoms are severe or persist."
        ),
    ),
    DiseaseRule(
        name="COVID-19",
        symptoms={"fever", "cough", "fatigue", "headache"},
        base_confidence=0.70,
        advice=(
            "Consider testing for COVID-19 and follow local guidance. Isolate if needed and monitor symptoms. "
            "Seek urgent care for difficulty breathing, chest pain, or confusion."
        ),
    ),
]


def normalize_symptoms(symptoms: list[str]) -> list[str]:
    cleaned: list[str] = []
    for s in symptoms:
        if not isinstance(s, str):
            continue
        v = s.strip().lower()
        if v and v not in cleaned:
            cleaned.append(v)
    return cleaned


def predict_from_symptoms(symptoms: list[str]) -> dict:
    """Rule-based prediction (kept intentionally simple & runnable without ML libs)."""

    s = set(normalize_symptoms(symptoms))

    scored: list[tuple[DiseaseRule, float, set[str]]] = []
    for rule in DISEASE_RULES:
        matches = rule.symptoms.intersection(s)
        if not matches:
            continue
        match_ratio = len(matches) / max(len(rule.symptoms), 1)
        score = match_ratio * rule.base_confidence
        scored.append((rule, score, matches))

    scored.sort(key=lambda x: x[1], reverse=True)

    if not scored:
        return {
            "prediction": "General health concern",
            "raw_prediction": "unknown",
            "confidence": 0.0,
            "probabilities": {},
            "suggestions": [
                "Use the Symptom Checker with more details",
                "Consult a healthcare professional for a proper diagnosis",
            ],
        }

    best_rule, best_score, _matches = scored[0]

    # Convert scores to a probability-like distribution for top 5
    top = scored[:5]
    total = sum(score for _r, score, _m in top) or 1.0
    probabilities = {r.name: score / total for r, score, _m in top}

    suggestions = [
        best_rule.advice,
        "If symptoms are severe, worsening, or include breathing difficulty, seek urgent medical attention.",
        "Stay hydrated and rest.",
    ]

    return {
        "prediction": best_rule.name,
        "raw_prediction": best_rule.name,
        "confidence": float(round(best_score, 4)),
        "probabilities": probabilities,
        "suggestions": suggestions,
    }


def detect_symptoms_in_text(message: str) -> list[str]:
    lower = (message or "").lower()
    found = [k for k in SYMPTOM_KEYWORDS if k in lower]
    return normalize_symptoms(found)
