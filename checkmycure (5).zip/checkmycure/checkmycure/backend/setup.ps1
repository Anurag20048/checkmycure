# Django Backend Setup Script

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "   Django Backend Setup" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

function Resolve-PythonExe {
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -and ($cmd.Source -notlike "*WindowsApps*")) {
        return $cmd.Source
    }

    $candidates = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python" -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "Python*" } |
        ForEach-Object {
            $p = Join-Path $_.FullName "python.exe"
            if (Test-Path $p) { $p }
        }

    if ($candidates) {
        return ($candidates | Select-Object -First 1)
    }

    throw "Python executable not found. Install Python from python.org and ensure it is on PATH."
}

$PYTHON = Resolve-PythonExe
Write-Host "Using Python: $PYTHON" -ForegroundColor Green

# Create virtual environment
Write-Host "[1/4] Creating virtual environment..." -ForegroundColor Yellow
& $PYTHON -m venv venv
Write-Host "✓ Virtual environment created" -ForegroundColor Green

$VENV_PYTHON = ".\venv\Scripts\python.exe"

Write-Host ""
Write-Host "[2/4] Virtual environment python: $VENV_PYTHON" -ForegroundColor Yellow

Write-Host ""
Write-Host "[3/4] Installing dependencies..." -ForegroundColor Yellow
& $VENV_PYTHON -m pip install -r requirements.txt
Write-Host "✓ Dependencies installed" -ForegroundColor Green

Write-Host ""
Write-Host "[4/4] Running initial migrations..." -ForegroundColor Yellow
& $VENV_PYTHON .\manage.py makemigrations
& $VENV_PYTHON .\manage.py migrate
Write-Host "✓ Migrations completed" -ForegroundColor Green

Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next: run .\\start.ps1" -ForegroundColor Yellow
