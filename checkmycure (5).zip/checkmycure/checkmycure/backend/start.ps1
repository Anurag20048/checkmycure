# Django Backend Quick Start Script

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "   Django Backend Quick Start" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

function Resolve-PythonExe {
    $cmd = Get-Command python -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -and ($cmd.Source -notlike "*WindowsApps*")) {
        return $cmd.Source
    }

    $candidates = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python" -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "Python*" } |
        ForEach-Object {
            $p = Join-Path $_.FullName "python.exe"
            if (Test-Path $p) { $p }
        }

    if ($candidates) {
        return ($candidates | Select-Object -First 1)
    }

    throw "Python executable not found. Install Python from python.org and ensure it is on PATH."
}

$PYTHON = Resolve-PythonExe
Write-Host "Using Python: $PYTHON" -ForegroundColor Green

# Check if virtual environment exists
if (!(Test-Path "venv")) {
    Write-Host "[1/5] Creating virtual environment..." -ForegroundColor Yellow
    & $PYTHON -m venv venv
    Write-Host "✓ Virtual environment created" -ForegroundColor Green
} else {
    Write-Host "[1/5] Virtual environment already exists" -ForegroundColor Green
}

$VENV_PYTHON = ".\venv\Scripts\python.exe"

Write-Host ""
Write-Host "[2/5] Virtual environment python: $VENV_PYTHON" -ForegroundColor Yellow

Write-Host ""
Write-Host "[3/5] Installing dependencies..." -ForegroundColor Yellow
& $VENV_PYTHON -m pip install -r requirements.txt --quiet
Write-Host "✓ Dependencies installed" -ForegroundColor Green

Write-Host ""
Write-Host "[4/5] Running migrations..." -ForegroundColor Yellow
& $VENV_PYTHON .\manage.py makemigrations
& $VENV_PYTHON .\manage.py migrate
Write-Host "✓ Migrations completed" -ForegroundColor Green

Write-Host ""
Write-Host "[5/5] Starting development server..." -ForegroundColor Yellow
Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Server running at: http://127.0.0.1:8001" -ForegroundColor Green
Write-Host "API available at: http://127.0.0.1:8001/api/" -ForegroundColor Green
Write-Host "Admin panel at: http://127.0.0.1:8001/admin/" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

& $VENV_PYTHON .\manage.py runserver 8001
