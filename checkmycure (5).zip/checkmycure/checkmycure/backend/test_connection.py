#!/usr/bin/env python
"""
Test script to verify database connection and API endpoints
"""

import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from django.db import connection

def test_database_connection():
    """Test database connection"""
    print("🔍 Testing database connection...")
    try:
        # Test database connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            result = cursor.fetchone()
            if result:
                print("✅ Database connection successful!")
                return True
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return False

def test_user_model():
    """Test User model"""
    print("\n🔍 Testing User model...")
    try:
        # Count users
        user_count = User.objects.count()
        print(f"✅ User model working! Found {user_count} users.")
        
        # List all users
        if user_count > 0:
            print("\n📋 Existing users:")
            for user in User.objects.all():
                print(f"  - {user.email} ({user.first_name})")
        return True
    except Exception as e:
        print(f"❌ User model test failed: {e}")
        return False

def test_token_model():
    """Test Token model"""
    print("\n🔍 Testing Token model...")
    try:
        token_count = Token.objects.count()
        print(f"✅ Token model working! Found {token_count} tokens.")
        return True
    except Exception as e:
        print(f"❌ Token model test failed: {e}")
        return False

def create_test_user():
    """Create a test user"""
    print("\n🔍 Creating test user...")
    try:
        # Check if test user exists
        if User.objects.filter(email='test@checkmycure.com').exists():
            print("⚠️  Test user already exists")
            user = User.objects.get(email='test@checkmycure.com')
        else:
            # Create test user
            user = User.objects.create_user(
                username='test@checkmycure.com',
                email='test@checkmycure.com',
                password='testpass123',
                first_name='Test User'
            )
            print("✅ Test user created successfully!")
        
        # Create or get token
        token, created = Token.objects.get_or_create(user=user)
        if created:
            print(f"✅ Token created: {token.key}")
        else:
            print(f"✅ Token exists: {token.key}")
        
        return True
    except Exception as e:
        print(f"❌ Failed to create test user: {e}")
        return False

def main():
    print("=" * 60)
    print("Check MyCure - Database Connection Test")
    print("=" * 60)
    
    results = []
    
    # Run tests
    results.append(("Database Connection", test_database_connection()))
    results.append(("User Model", test_user_model()))
    results.append(("Token Model", test_token_model()))
    results.append(("Test User Creation", create_test_user()))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n🎉 All tests passed! Database is ready.")
        print("\n📝 Next steps:")
        print("1. Start Django server: python manage.py runserver 8001")
        print("2. Test registration: POST http://localhost:8001/api/auth/register/")
        print("3. Test login: POST http://localhost:8001/api/auth/login/")
    else:
        print("\n⚠️  Some tests failed. Please check the errors above.")
        print("\n🔧 Troubleshooting:")
        print("1. Run: python manage.py makemigrations")
        print("2. Run: python manage.py migrate")
        print("3. Try again: python test_connection.py")
    
    print("=" * 60)

if __name__ == '__main__':
    main()
